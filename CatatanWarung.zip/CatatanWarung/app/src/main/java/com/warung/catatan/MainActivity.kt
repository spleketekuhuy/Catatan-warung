package com.warung.catatan

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/* ---------- data ---------- */

data class Item(
    val id: String,
    val name: String,
    val price: Long,
    val cat: String,
    val qty: Int = 1
)

val Item.subtotal: Long get() = price * qty

private val DEFAULT_CATS = listOf("Sembako", "Minuman", "Jajanan", "Kebutuhan rumah")

fun rp(n: Long): String = "Rp " + n.toString().reversed().chunked(3).joinToString(".").reversed()
fun catLabel(c: String): String = if (c.isEmpty()) "Tanpa kategori" else c
fun digits(s: String): String = s.filter { it.isDigit() }.take(12)

class WarungState(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("warung", Context.MODE_PRIVATE)

    var categories by mutableStateOf(DEFAULT_CATS)
        private set
    var items by mutableStateOf(emptyList<Item>())
        private set

    init {
        load()
    }

    private fun load() {
        val raw = prefs.getString("data", null) ?: return
        try {
            val o = JSONObject(raw)
            val cats = o.getJSONArray("categories")
            categories = (0 until cats.length()).map { cats.getString(it) }
            val arr = o.getJSONArray("items")
            items = (0 until arr.length()).map {
                val x = arr.getJSONObject(it)
                Item(
                    x.getString("id"),
                    x.getString("name"),
                    x.getLong("price"),
                    x.optString("cat", ""),
                    x.optInt("qty", 1)
                )
            }
        } catch (e: Exception) {
            // data rusak: mulai dari daftar kosong
        }
    }

    private fun save() {
        val o = JSONObject()
        o.put("categories", JSONArray(categories))
        val arr = JSONArray()
        items.forEach {
            val x = JSONObject()
            x.put("id", it.id)
            x.put("name", it.name)
            x.put("price", it.price)
            x.put("cat", it.cat)
            x.put("qty", it.qty)
            arr.put(x)
        }
        o.put("items", arr)
        prefs.edit().putString("data", o.toString()).apply()
    }

    fun addItem(name: String, price: Long, cat: String, qty: Int) {
        items = items + Item(UUID.randomUUID().toString(), name.trim(), price, cat, qty)
        save()
    }

    fun updateItem(id: String, name: String, price: Long, qty: Int) {
        items = items.map {
            if (it.id == id) it.copy(name = name.trim(), price = price, qty = qty) else it
        }
        save()
    }

    fun changeQty(id: String, delta: Int) {
        items = items.map {
            if (it.id == id) it.copy(qty = (it.qty + delta).coerceIn(0, 99999)) else it
        }
        save()
    }

    fun setCategory(id: String, cat: String) {
        items = items.map { if (it.id == id) it.copy(cat = cat) else it }
        save()
    }

    fun deleteItem(id: String) {
        items = items.filter { it.id != id }
        save()
    }

    fun addCategory(name: String): String? {
        val n = name.trim()
        if (n.isEmpty()) return "Isi nama kategori dulu."
        if (categories.any { it.equals(n, ignoreCase = true) }) return "Kategori $n sudah ada."
        categories = categories + n
        save()
        return null
    }

    fun renameCategory(old: String, name: String): String? {
        val n = name.trim()
        if (n.isEmpty()) return "Nama kategori tidak boleh kosong."
        if (categories.any { it != old && it.equals(n, ignoreCase = true) }) return "Kategori $n sudah ada."
        categories = categories.map { if (it == old) n else it }
        items = items.map { if (it.cat == old) it.copy(cat = n) else it }
        save()
        return null
    }

    fun deleteCategory(c: String) {
        categories = categories.filter { it != c }
        items = items.map { if (it.cat == c) it.copy(cat = "") else it }
        save()
    }
}

/* ---------- activity & tema ---------- */

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        val state = WarungState(applicationContext)
        setContent {
            WarungTheme {
                WarungApp(state)
            }
        }
    }
}

@Composable
fun WarungTheme(content: @Composable () -> Unit) {
    val scheme = if (isSystemInDarkTheme()) {
        darkColorScheme(
            primary = Color(0xFFEF5350),
            onPrimary = Color(0xFF1A0000),
            primaryContainer = Color(0xFF7F1D1D),
            onPrimaryContainer = Color(0xFFFFDAD6),
            secondaryContainer = Color(0xFF4A2523),
            onSecondaryContainer = Color(0xFFFFDAD6),
            background = Color(0xFF1B1110),
            onBackground = Color(0xFFF5E4E2),
            surface = Color(0xFF261918),
            onSurface = Color(0xFFF5E4E2),
            surfaceVariant = Color(0xFF53433F),
            onSurfaceVariant = Color(0xFFD8C2BE),
            outline = Color(0xFFA08C89)
        )
    } else {
        lightColorScheme(
            primary = Color(0xFFC62828),
            onPrimary = Color.White,
            primaryContainer = Color(0xFFFFDAD6),
            onPrimaryContainer = Color(0xFF410002),
            secondaryContainer = Color(0xFFFFE0DC),
            onSecondaryContainer = Color(0xFF410002),
            background = Color(0xFFFFF3F1),
            onBackground = Color(0xFF231918),
            surface = Color.White,
            onSurface = Color(0xFF231918),
            surfaceVariant = Color(0xFFF5DDDA),
            onSurfaceVariant = Color(0xFF534341),
            outline = Color(0xFF857370)
        )
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

/* ---------- layar utama ---------- */

@Composable
fun WarungApp(state: WarungState) {
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val say: (String) -> Unit = { msg ->
        scope.launch {
            snackbar.currentSnackbarData?.dismiss()
            snackbar.showSnackbar(msg)
        }
    }

    val context = LocalContext.current
    val exporter = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument(
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        )
    ) { uri ->
        if (uri != null) {
            try {
                val bytes = XlsxExporter.build(state.items, state.categories)
                context.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                say("Berkas Excel tersimpan.")
            } catch (e: Exception) {
                say("Gagal menyimpan berkas Excel.")
            }
        }
    }

    var filter by rememberSaveable { mutableStateOf("all") }
    var showManage by rememberSaveable { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Item?>(null) }
    var deleting by remember { mutableStateOf<Item?>(null) }

    val cats = state.categories
    val items = state.items
    val noneCount = items.count { it.cat.isEmpty() }
    val eff = when {
        filter.startsWith("c:") && filter.removePrefix("c:") in cats -> filter
        filter == "none" && noneCount > 0 -> filter
        else -> "all"
    }

    val groups = buildList<Triple<String, String, List<Item>>> {
        cats.forEach { c ->
            add(Triple("c:$c", c, items.filter { it.cat == c }.sortedBy { it.name.lowercase() }))
        }
        val none = items.filter { it.cat.isEmpty() }.sortedBy { it.name.lowercase() }
        if (none.isNotEmpty()) add(Triple("none", "Tanpa kategori", none))
    }
    val shown = if (eff == "all") groups.filter { it.third.isNotEmpty() } else groups.filter { it.first == eff }

    val total = items.sumOf { it.subtotal }
    val totalQty = items.sumOf { it.qty }
    val sub = if (eff == "all") {
        "${items.size} jenis · $totalQty buah"
    } else {
        val g = groups.firstOrNull { it.first == eff }
        "${items.size} jenis · $totalQty buah · ${g?.second ?: ""}: ${rp(g?.third?.sumOf { it.subtotal } ?: 0L)}"
    }

    Scaffold(
        contentWindowInsets = WindowInsets(0.dp, 0.dp, 0.dp, 0.dp),
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = { TotalBar(total, sub) }
    ) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize()) {
            item { Banner() }
            item { AddForm(state, say) }
            item {
                FilterBar(
                    cats = cats,
                    items = items,
                    eff = eff,
                    noneCount = noneCount,
                    onPick = { filter = it },
                    onManage = { showManage = true },
                    onExport = {
                        if (items.isEmpty()) {
                            say("Belum ada barang untuk diekspor.")
                        } else {
                            exporter.launch("Catatan-Warung-${java.time.LocalDate.now()}.xlsx")
                        }
                    }
                )
            }
            if (items.isEmpty()) {
                item {
                    Text(
                        "Belum ada barang. Isi nama, harga, dan jumlah di atas, lalu tekan Tambah barang.",
                        modifier = Modifier.padding(16.dp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else if (shown.all { it.third.isEmpty() }) {
                item {
                    Text(
                        "Kategori ini masih kosong. Pindahkan barang ke sini lewat pilihan kategori di setiap barang.",
                        modifier = Modifier.padding(16.dp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            shown.forEach { g ->
                if (g.third.isNotEmpty()) {
                    item(key = "h-" + g.first) {
                        GroupHeader(g.second, g.third.size, g.third.sumOf { it.subtotal })
                    }
                    items(g.third, key = { it.id }) { row ->
                        ItemRow(
                            item = row,
                            categories = cats,
                            onCat = { c ->
                                state.setCategory(row.id, c)
                                say("${row.name} dipindah ke ${catLabel(c)}.")
                            },
                            onQty = { d -> state.changeQty(row.id, d) },
                            onEdit = { editing = row },
                            onDelete = { deleting = row }
                        )
                    }
                }
            }
            item { Spacer(Modifier.height(16.dp)) }
        }
    }

    editing?.let { it0 ->
        EditDialog(
            item = it0,
            onSave = { n, p, q ->
                state.updateItem(it0.id, n, p, q)
                editing = null
                say("Perubahan ${n.trim()} disimpan.")
            },
            onDismiss = { editing = null }
        )
    }

    deleting?.let { it0 ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Hapus barang?") },
            text = { Text("${it0.name} (${it0.qty} x ${rp(it0.price)}) akan dihapus dari daftar.") },
            confirmButton = {
                TextButton(onClick = {
                    state.deleteItem(it0.id)
                    deleting = null
                    say("${it0.name} dihapus.")
                }) { Text("Hapus", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Batal") } }
        )
    }

    if (showManage) {
        ManageDialog(state = state, onClose = { showManage = false })
    }
}

@Composable
fun Banner() {
    Surface(
        color = MaterialTheme.colorScheme.primary,
        contentColor = MaterialTheme.colorScheme.onPrimary,
        shape = RoundedCornerShape(bottomStart = 32.dp, bottomEnd = 32.dp),
        shadowElevation = 4.dp
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 20.dp, vertical = 22.dp)
        ) {
            Text(
                "Catatan Warung",
                fontSize = 32.sp,
                fontWeight = FontWeight.ExtraBold
            )
            Spacer(Modifier.height(2.dp))
            Text(
                "Harga, jumlah, dan total barang warung Anda",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.85f)
            )
        }
    }
}

@Composable
fun TotalBar(total: Long, sub: String) {
    Surface(
        color = MaterialTheme.colorScheme.primary,
        contentColor = MaterialTheme.colorScheme.onPrimary,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        shadowElevation = 12.dp
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    "TOTAL SEMUA BARANG",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.85f)
                )
                Text(
                    sub,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.85f)
                )
            }
            Spacer(Modifier.width(12.dp))
            Text(
                rp(total),
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                maxLines = 1
            )
        }
    }
}

@Composable
fun AddForm(state: WarungState, say: (String) -> Unit) {
    var name by rememberSaveable { mutableStateOf("") }
    var price by rememberSaveable { mutableStateOf("") }
    var qty by rememberSaveable { mutableStateOf("1") }
    var cat by rememberSaveable { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val effCat = if (cat in state.categories) cat else ""

    Card(
        modifier = Modifier.fillMaxWidth().padding(16.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Column(
            Modifier.fillMaxWidth().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                "Tambah barang",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            OutlinedTextField(
                value = name,
                onValueChange = { name = it.take(80) },
                label = { Text("Nama barang") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = price,
                    onValueChange = { price = digits(it) },
                    label = { Text("Harga satuan (Rp)") },
                    supportingText = { if (price.isNotEmpty()) Text(rp(price.toLong())) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = qty,
                    onValueChange = { qty = digits(it).take(5) },
                    label = { Text("Jumlah") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.width(110.dp)
                )
            }
            CategoryPicker(
                selected = effCat,
                categories = state.categories,
                onSelect = { cat = it },
                modifier = Modifier.fillMaxWidth(),
                height = 48.dp
            )
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            Button(
                onClick = {
                    val p = price.toLongOrNull()
                    val q = qty.toIntOrNull() ?: 1
                    if (name.isBlank()) {
                        error = "Isi nama barang dulu."
                    } else if (p == null) {
                        error = "Isi harga barang."
                    } else {
                        state.addItem(name, p, effCat, q)
                        say("${name.trim()} x $q masuk ke ${catLabel(effCat)}.")
                        name = ""
                        price = ""
                        qty = "1"
                        error = null
                    }
                },
                modifier = Modifier.fillMaxWidth().height(50.dp)
            ) { Text("Tambah barang", fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
fun CategoryPicker(
    selected: String,
    categories: List<String>,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier,
    height: Dp = 40.dp
) {
    var open by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedButton(
            onClick = { open = true },
            modifier = Modifier.fillMaxWidth().height(height)
        ) {
            Text(catLabel(selected), maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            DropdownMenuItem(
                text = { Text("Tanpa kategori") },
                onClick = { onSelect(""); open = false }
            )
            categories.forEach { c ->
                DropdownMenuItem(
                    text = { Text(c) },
                    onClick = { onSelect(c); open = false }
                )
            }
        }
    }
}

@Composable
fun FilterBar(
    cats: List<String>,
    items: List<Item>,
    eff: String,
    noneCount: Int,
    onPick: (String) -> Unit,
    onManage: () -> Unit,
    onExport: () -> Unit
) {
    val chipColors = FilterChipDefaults.filterChipColors(
        selectedContainerColor = MaterialTheme.colorScheme.primary,
        selectedLabelColor = MaterialTheme.colorScheme.onPrimary
    )
    Column {
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                FilterChip(
                    selected = eff == "all",
                    onClick = { onPick("all") },
                    label = { Text("Semua ${items.size}") },
                    colors = chipColors
                )
            }
            items(cats) { c ->
                FilterChip(
                    selected = eff == "c:$c",
                    onClick = { onPick("c:$c") },
                    label = { Text("$c ${items.count { it.cat == c }}") },
                    colors = chipColors
                )
            }
            if (noneCount > 0) {
                item {
                    FilterChip(
                        selected = eff == "none",
                        onClick = { onPick("none") },
                        label = { Text("Tanpa kategori $noneCount") },
                        colors = chipColors
                    )
                }
            }
        }
        Row(Modifier.padding(horizontal = 8.dp)) {
            TextButton(onClick = onManage) {
                Text("Atur kategori", fontWeight = FontWeight.Bold)
            }
            TextButton(onClick = onExport) {
                Text("Ekspor ke Excel", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun GroupHeader(name: String, count: Int, sum: Long) {
    Surface(color = MaterialTheme.colorScheme.secondaryContainer) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                name.uppercase(),
                modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.onSecondaryContainer
            )
            Text(
                "$count jenis · ${rp(sum)}",
                style = MaterialTheme.typography.bodySmall,
                fontFamily = FontFamily.Monospace,
                color = MaterialTheme.colorScheme.onSecondaryContainer
            )
        }
    }
}

@Composable
fun ItemRow(
    item: Item,
    categories: List<String>,
    onCat: (String) -> Unit,
    onQty: (Int) -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Column(Modifier.fillMaxWidth()) {
        Column(
            Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(verticalAlignment = Alignment.Top) {
                Text(
                    item.name,
                    modifier = Modifier.weight(1f),
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.width(12.dp))
                Text(
                    rp(item.subtotal),
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(
                    onClick = { onQty(-1) },
                    enabled = item.qty > 0,
                    contentPadding = PaddingValues(0.dp),
                    modifier = Modifier.size(40.dp)
                ) { Text("-", fontSize = 22.sp) }
                Text(
                    "${item.qty}",
                    modifier = Modifier.widthIn(min = 52.dp),
                    textAlign = TextAlign.Center,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Button(
                    onClick = { onQty(1) },
                    contentPadding = PaddingValues(0.dp),
                    modifier = Modifier.size(40.dp)
                ) { Text("+", fontSize = 22.sp) }
                Spacer(Modifier.width(12.dp))
                Text(
                    "x ${rp(item.price)}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                CategoryPicker(
                    selected = item.cat,
                    categories = categories,
                    onSelect = onCat,
                    modifier = Modifier.weight(1f)
                )
                TextButton(onClick = onEdit) { Text("Ubah") }
                TextButton(onClick = onDelete) {
                    Text("Hapus", color = MaterialTheme.colorScheme.error)
                }
            }
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
    }
}

/* ---------- dialog ---------- */

@Composable
fun EditDialog(item: Item, onSave: (String, Long, Int) -> Unit, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf(item.name) }
    var price by remember { mutableStateOf(item.price.toString()) }
    var qty by remember { mutableStateOf(item.qty.toString()) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Ubah barang") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it.take(80) },
                    label = { Text("Nama barang") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = price,
                    onValueChange = { price = digits(it) },
                    label = { Text("Harga satuan (Rp)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                OutlinedTextField(
                    value = qty,
                    onValueChange = { qty = digits(it).take(5) },
                    label = { Text("Jumlah") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val p = price.toLongOrNull()
                val q = qty.toIntOrNull() ?: 0
                if (name.isBlank()) {
                    error = "Nama barang tidak boleh kosong."
                } else if (p == null) {
                    error = "Isi harga barang."
                } else {
                    onSave(name, p, q)
                }
            }) { Text("Simpan") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}

@Composable
fun ManageDialog(state: WarungState, onClose: () -> Unit) {
    var newCat by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf<String?>(null) }
    val report: (String) -> Unit = { msg = it }

    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Atur kategori") },
        confirmButton = { TextButton(onClick = onClose) { Text("Selesai") } },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                state.categories.forEach { c ->
                    key(c) {
                        CategoryEditRow(
                            c = c,
                            count = state.items.count { it.cat == c },
                            state = state,
                            report = report
                        )
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = newCat,
                        onValueChange = { newCat = it.take(40) },
                        label = { Text("Kategori baru") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = {
                        val e = state.addCategory(newCat)
                        if (e == null) {
                            report("Kategori ${newCat.trim()} ditambahkan.")
                            newCat = ""
                        } else {
                            report(e)
                        }
                    }) { Text("Tambah") }
                }
                msg?.let { Text(it, color = MaterialTheme.colorScheme.primary) }
                Text(
                    "Menghapus kategori tidak menghapus barang. Barangnya pindah ke Tanpa kategori.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    )
}

@Composable
fun CategoryEditRow(c: String, count: Int, state: WarungState, report: (String) -> Unit) {
    var text by remember { mutableStateOf(c) }
    var confirm by remember { mutableStateOf(false) }

    Column {
        OutlinedTextField(
            value = text,
            onValueChange = { text = it.take(40) },
            label = { Text("$count jenis barang") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Row {
            TextButton(
                enabled = text.trim() != c,
                onClick = {
                    val e = state.renameCategory(c, text)
                    if (e == null) {
                        report("Kategori diganti jadi ${text.trim()}.")
                    } else {
                        report(e)
                    }
                }
            ) { Text("Simpan nama") }
            TextButton(onClick = {
                if (confirm) {
                    state.deleteCategory(c)
                    report("Kategori $c dihapus.")
                } else {
                    confirm = true
                }
            }) {
                Text(
                    if (confirm) "Yakin hapus?" else "Hapus",
                    color = MaterialTheme.colorScheme.error
                )
            }
        }
    }
}

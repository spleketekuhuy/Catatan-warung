package com.warung.catatan

import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Menulis berkas .xlsx sederhana tanpa pustaka tambahan. */
object XlsxExporter {

    private const val XML = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"

    private val CONTENT_TYPES = XML + """<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>"""

    private val ROOT_RELS = XML + """<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>"""

    private val WORKBOOK = XML + """<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Barang" sheetId="1" r:id="rId1"/></sheets></workbook>"""

    private val WORKBOOK_RELS = XML + """<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>"""

    private val STYLES = XML + """<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts><fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="4"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/><xf numFmtId="3" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/><xf numFmtId="3" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1" applyNumberFormat="1"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>"""

    private const val COLS =
        "<cols>" +
            "<col min=\"1\" max=\"1\" width=\"6\" customWidth=\"1\"/>" +
            "<col min=\"2\" max=\"2\" width=\"34\" customWidth=\"1\"/>" +
            "<col min=\"3\" max=\"3\" width=\"20\" customWidth=\"1\"/>" +
            "<col min=\"4\" max=\"4\" width=\"18\" customWidth=\"1\"/>" +
            "<col min=\"5\" max=\"5\" width=\"10\" customWidth=\"1\"/>" +
            "<col min=\"6\" max=\"6\" width=\"18\" customWidth=\"1\"/>" +
            "</cols>"

    private fun esc(s: String): String =
        s.filter { it.code >= 32 }
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")

    private fun str(ref: String, text: String, style: Int = 0): String =
        "<c r=\"$ref\" s=\"$style\" t=\"inlineStr\"><is><t xml:space=\"preserve\">${esc(text)}</t></is></c>"

    private fun num(ref: String, v: Long, style: Int = 2): String =
        "<c r=\"$ref\" s=\"$style\"><v>$v</v></c>"

    private fun formula(ref: String, f: String, v: Long, style: Int = 2): String =
        "<c r=\"$ref\" s=\"$style\"><f>$f</f><v>$v</v></c>"

    fun build(items: List<Item>, categories: List<String>): ByteArray {
        val ordered = categories.flatMap { c ->
            items.filter { it.cat == c }.sortedBy { it.name.lowercase() }
        } + items.filter { it.cat.isEmpty() || it.cat !in categories }
            .sortedBy { it.name.lowercase() }

        val rows = StringBuilder()
        rows.append("<row r=\"1\">")
        listOf("No", "Nama Barang", "Kategori", "Harga Satuan (Rp)", "Jumlah", "Subtotal (Rp)")
            .forEachIndexed { i, h -> rows.append(str("${'A' + i}1", h, 1)) }
        rows.append("</row>")

        ordered.forEachIndexed { idx, item ->
            val r = idx + 2
            rows.append("<row r=\"$r\">")
            rows.append(num("A$r", (idx + 1).toLong(), 0))
            rows.append(str("B$r", item.name))
            rows.append(str("C$r", catLabel(item.cat)))
            rows.append(num("D$r", item.price))
            rows.append(num("E$r", item.qty.toLong()))
            rows.append(formula("F$r", "D$r*E$r", item.subtotal))
            rows.append("</row>")
        }

        val t = ordered.size + 2
        val totalQty = ordered.sumOf { it.qty.toLong() }
        val total = ordered.sumOf { it.subtotal }
        rows.append("<row r=\"$t\">")
        rows.append(str("B$t", "TOTAL", 1))
        if (ordered.isEmpty()) {
            rows.append(num("E$t", 0L, 3))
            rows.append(num("F$t", 0L, 3))
        } else {
            rows.append(formula("E$t", "SUM(E2:E${t - 1})", totalQty, 3))
            rows.append(formula("F$t", "SUM(F2:F${t - 1})", total, 3))
        }
        rows.append("</row>")

        val sheet = XML +
            "<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">" +
            COLS + "<sheetData>" + rows + "</sheetData></worksheet>"

        val bos = ByteArrayOutputStream()
        ZipOutputStream(bos).use { z ->
            fun put(name: String, content: String) {
                z.putNextEntry(ZipEntry(name))
                z.write(content.toByteArray(Charsets.UTF_8))
                z.closeEntry()
            }
            put("[Content_Types].xml", CONTENT_TYPES)
            put("_rels/.rels", ROOT_RELS)
            put("xl/workbook.xml", WORKBOOK)
            put("xl/_rels/workbook.xml.rels", WORKBOOK_RELS)
            put("xl/styles.xml", STYLES)
            put("xl/worksheets/sheet1.xml", sheet)
        }
        return bos.toByteArray()
    }
}

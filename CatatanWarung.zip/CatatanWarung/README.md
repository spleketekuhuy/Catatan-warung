# Catatan Warung (Android native)

Aplikasi Android native (Kotlin + Jetpack Compose), tanpa WebView. Fitur:
nama barang, harga, total semua barang, dan kategori yang bisa ditambah,
diganti nama, dihapus, serta dipilih ulang untuk setiap barang.
Data tersimpan di HP (SharedPreferences), tanpa internet.

## Cara A: Android Studio (di komputer)

1. Pasang Android Studio (versi terbaru) dari developer.android.com/studio.
2. Ekstrak zip ini, lalu di Android Studio pilih File > Open dan pilih folder `CatatanWarung`.
3. Tunggu "Gradle sync" selesai (butuh internet untuk mengunduh pustaka, sekali saja).
4. Pilih menu Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Klik "locate" pada notifikasi yang muncul. Berkas ada di:
   `app/build/outputs/apk/debug/app-debug.apk`
6. Kirim berkas itu ke HP, buka, dan izinkan "pasang dari sumber tidak dikenal" jika diminta.

## Cara B: GitHub Actions (tanpa memasang apa pun)

Dikerjakan lewat browser di komputer. GitHub yang membangun APK-nya.

1. Buat akun di github.com, lalu buat repositori baru (New repository), misalnya `catatan-warung`.
2. Ekstrak zip ini. Di halaman repositori pilih Add file > Upload files.
3. Seret SEMUA isi folder `CatatanWarung` ke halaman itu, termasuk folder `.github`,
   `app`, dan `gradle`. Folder `.github` tersembunyi: di Mac tekan Cmd+Shift+titik
   di Finder untuk menampilkannya, di Windows aktifkan "Item tersembunyi" di menu Tampilan.
4. Tekan Commit changes. Build berjalan otomatis.
5. Buka tab Actions, pilih proses "Build APK" yang terbaru, tunggu sampai centang hijau
   (sekitar 5 sampai 10 menit).
6. Di bagian Artifacts pada halaman proses itu, unduh `CatatanWarung-apk`.
   Ekstrak zipnya, isinya `app-debug.apk`.
7. Kirim ke HP, buka, dan izinkan "pasang dari sumber tidak dikenal" jika diminta.

Jika proses berwarna merah, buka prosesnya, salin pesan galat di langkah "Build debug APK",
dan minta perbaikan.

## Catatan

APK debug cukup untuk dipakai sendiri. Untuk Play Store, buat APK/AAB bertanda tangan
lewat Build > Generate Signed Bundle / APK.

Proyek ini belum pernah dikompilasi oleh pembuatnya, jadi galat kecil saat build pertama
mungkin terjadi.
